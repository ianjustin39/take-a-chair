package name.qd.fileCache.cache;

public abstract class CoordinateObject implements FileCacheObject {
	public abstract String getXKey();
	public abstract String getYKey();
}
