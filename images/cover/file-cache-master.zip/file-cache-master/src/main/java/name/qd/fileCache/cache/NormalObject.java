package name.qd.fileCache.cache;

public abstract class NormalObject implements FileCacheObject {
	public abstract String getKeyString();
}
